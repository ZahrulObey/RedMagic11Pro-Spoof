SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

print_modname() {
  ui_print ""
  ui_print "  ╔══════════════════════════════════╗"
  ui_print "  ║                                  ║"
  ui_print "  ║   🎮  RED MAGIC 11 PRO SPOOF  🎮  ║"
  ui_print "  ║                                  ║"
  ui_print "  ║       ZTE Nubia Red Magic        ║"
  ui_print "  ║           11 Pro [NX769J]        ║"
  ui_print "  ║                                  ║"
  ui_print "  ║        by  Z a h r u l O b e y   ║"
  ui_print "  ║                                  ║"
  ui_print "  ╚══════════════════════════════════╝"
  ui_print ""
}

on_install() {
  ui_print "  ┌─────────────────────────────────┐"
  ui_print "  │        DEVICE  SPOOFING         │"
  ui_print "  └─────────────────────────────────┘"
  ui_print ""
  ui_print "  ⚡ Snapdragon 8 Elite  →  SM8750"
  sleep 1
  ui_print "  ⚡ GPU Adreno 830      →  Spoofed"
  sleep 1
  ui_print "  ⚡ Model               →  NX769J"
  sleep 1
  ui_print "  ⚡ Brand               →  Nubia"
  sleep 1
  ui_print ""
  ui_print "  ┌─────────────────────────────────┐"
  ui_print "  │           INSTALLING            │"
  ui_print "  └─────────────────────────────────┘"
  ui_print ""
  ui_print "  [ ██████████████████████ ]  100%"
  sleep 1
  ui_print ""
  ui_print "  ┌─────────────────────────────────┐"
  ui_print "  │      ✅  INSTALL  SUCCESS!      │"
  ui_print "  └─────────────────────────────────┘"
  ui_print ""
  ui_print "  🔓 Unlock 120FPS in CODM & BGMI"
  ui_print ""
  ui_print "  ⚠  Reboot your device to apply!"
  ui_print ""
  ui_print "  ╔══════════════════════════════════╗"
  ui_print "  ║   Thanks for using this module!  ║"
  ui_print "  ║        ~ ZahrulObey ~            ║"
  ui_print "  ╚══════════════════════════════════╝"
  ui_print ""
}

MOD_EXTRACT() {
  unzip -o "$ZIPFILE" system/* -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}
